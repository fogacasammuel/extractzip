<?php

phpinfo();

echo "Atualizou nosso index.php";